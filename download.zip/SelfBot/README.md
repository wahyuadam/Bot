# SelfBot

Run bot without pc or of Android :
- Download Termux & Install
- pkg install python2
- pkg install git
- git clone https://github.com/treerach/SelfBot
- pip2 install thrift==0.9.3
- pip2 install rsa
- pip2 install requests
- pkg install nano
- cd SelfBot
- python2 treebot.py
- Done
